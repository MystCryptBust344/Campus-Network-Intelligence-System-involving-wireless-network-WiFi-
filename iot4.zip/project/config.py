# config.py

# Default coordinates if geolocation fails
DEFAULT_COORDINATES = (37.7749, -122.4194)

# Transmit power reference (in dBm) used for distance estimation
TX_POWER = -30

# Environment types: 'indoor', 'outdoor_urban', etc.
DEFAULT_ENVIRONMENT = 'indoor'

# WiFi data collection parameters
DEVICE_SCAN_INTERVAL = 10.0  # seconds
DATA_COLLECTION_INTERVAL = 1.0  # seconds
DATA_COLLECTION_DURATION = 5.0  # minutes

# Dash server port
DASH_PORT = 8050

# Dead zone detection parameters
DEAD_ZONE_SIGNAL_THRESHOLD = -80  # dBm cutoff for weak signal
DBSCAN_EPS_METERS = 20.0          # Neighborhood radius (meters)
DBSCAN_MIN_SAMPLES = 5            # Min points in cluster for DBSCAN

# AP scanning interval (multi-SSID coverage mapping)
AP_SCAN_INTERVAL = 30.0  # seconds

# BEGIN ADVANCED CHANGE
# Optional path to a scikit-learn model for distance estimation
ML_MODEL_PATH = "model_distance.pkl"

# Optional path to a Gaussian Process model or data
GP_MODEL_PATH = "model_distance_gp.pkl"

# Allowed environment classes in the environment classifier
ENV_CLASSES = ['indoor', 'outdoor_urban', 'outdoor_suburban', 'outdoor_open', 'nlos']
# END ADVANCED CHANGE
