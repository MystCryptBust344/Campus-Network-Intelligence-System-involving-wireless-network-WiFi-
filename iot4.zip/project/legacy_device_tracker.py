from imports import *
from config import DEFAULT_COORDINATES
from distance_estimator import EnhancedDistanceEstimator

class LegacyDeviceTracker:
    """Legacy DeviceTracker for tracking devices and their distances."""
    def __init__(self):
        self.devices = {}
        self.device_distances = []
        self.current_location = None
        if wmi:
            self.w = wmi.WMI()
        else:
            self.w = None
        # Initialize the enhanced distance estimator
        self.distance_estimator = EnhancedDistanceEstimator(environment='indoor')

    def get_current_location(self) -> Tuple[float, float]:
        try:
            response = requests.get('https://ipinfo.io/json')
            if response.status_code == 200:
                data = response.json()
                if 'loc' in data:
                    lat, lng = map(float, data['loc'].split(','))
                    self.current_location = (lat, lng)
                    return (lat, lng)
        except Exception as e:
            logging.error(f"Error getting geolocation: {e}")
        if not self.current_location:
            self.current_location = DEFAULT_COORDINATES
        return self.current_location

    def scan_network_devices(self) -> List[Dict]:
        connected_devices = []
        try:
            hostname = socket.gethostname()
            local_ip = socket.gethostbyname(hostname)
            ip_parts = local_ip.split('.')
            network_prefix = '.'.join(ip_parts[:-1])
            arp_request = scapy.ARP(pdst=f"{network_prefix}.0/24")
            broadcast = scapy.Ether(dst="ff:ff:ff:ff:ff:ff")
            arp_request_broadcast = broadcast/arp_request
            answered_list = scapy.srp(arp_request_broadcast, timeout=1, verbose=False)[0]
            current_time = time.time()
            lat, lng = self.get_current_location()
            for element in answered_list:
                ip = element[1].psrc
                mac = element[1].hwsrc
                if ip == local_ip:
                    continue
                signal_strength = None
                try:
                    if self.w:
                        for interface in self.w.Win32_NetworkAdapter():
                            if interface.NetConnectionStatus == 2:
                                network_config = self.w.query(f"SELECT * FROM Win32_NetworkAdapterConfiguration WHERE Index = {interface.Index}")
                                if network_config:
                                    for config in network_config:
                                        if hasattr(config, 'IPAddress') and config.IPAddress and ip in config.IPAddress:
                                            wireless_interface = self.w.query("SELECT * FROM MSNdis_80211_ReceivedSignalStrength")
                                            if wireless_interface:
                                                for wi in wireless_interface:
                                                    if hasattr(wi, 'Ndis80211ReceivedSignalStrength'):
                                                        signal_strength = wi.Ndis80211ReceivedSignalStrength
                                                        break
                except Exception as wmi_err:
                    logging.warning(f"WMI error for device {ip}: {wmi_err}")
                if not signal_strength:
                    try:
                        ping_cmd = ['ping', '-n', '1'] if platform.system().lower() == 'windows' else ['ping', '-c', '1']
                        ping_cmd.append(ip)
                        ping_result = subprocess.run(
                            ping_cmd,
                            stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE,
                            timeout=1,
                            text=True
                        )
                        latency_match = re.search(r'time=(\d+)ms', ping_result.stdout)
                        if latency_match:
                            latency = int(latency_match.group(1))
                            latency = max(5, min(1000, latency))
                            signal_strength = max(-90, min(-30, -30 - (latency * 0.5)))
                    except (subprocess.SubprocessError, subprocess.TimeoutExpired):
                        signal_strength = -85
                # Use the enhanced estimator to compute distance
                if signal_strength is not None:
                    distance = self.distance_estimator.estimate_distance(
                        signal_strength,
                        model='log_distance',
                        apply_kalman=False,
                        apply_shadowing=False
                    )
                else:
                    distance = 0
                # Compute device location using computed distance and a fixed bearing
                if distance > 0:
                    if mac in self.devices and 'bearing' in self.devices[mac]:
                        bearing = self.devices[mac]['bearing']
                    else:
                        bearing = np.random.uniform(0, 360)
                        if mac in self.devices:
                            self.devices[mac]['bearing'] = bearing
                        else:
                            self.devices[mac] = {'bearing': bearing}
                    lat_offset = distance * math.cos(math.radians(bearing)) / 111320
                    lng_offset = distance * math.sin(math.radians(bearing)) / (111320 * math.cos(math.radians(lat)))
                    device_location = (lat + lat_offset, lng + lng_offset)
                else:
                    device_location = (lat, lng)
                try:
                    calc_distance = geopy.distance.distance((lat, lng), device_location).meters
                except Exception as e:
                    logging.warning(f"Error calculating distance: {e}")
                    calc_distance = 0
                device_info = {
                    'ip': ip,
                    'mac': mac,
                    'time': current_time,
                    'signal_strength': signal_strength,
                    'location': device_location,
                    'distance': calc_distance,
                    'host_location': (lat, lng)
                }
                self.devices[mac] = device_info
                connected_devices.append(device_info)
                self.device_distances.append({
                    'time': current_time,
                    'device_id': mac,
                    'distance': calc_distance,
                    'lat': device_location[0],
                    'lng': device_location[1],
                    'signal_strength': signal_strength
                })
            return connected_devices
        except Exception as e:
            logging.error(f"Error scanning network: {e}")
            return []
