# deadzone_detector.py

"""
Enhanced DeadZoneDetector with:
- Dynamic thresholding (static or percentile-based)
- Spatial interpolation for heatmap overlay (using RBF)
- Clustering enhancements: DBSCAN and KMeans options
- Optional ML classification for dead zone detection
- Incorporation of device disconnection data as extremely weak signal points
- Stub for dead zone validation/removal (to account for transient conditions)
"""

import time
import logging
import numpy as np
import pandas as pd
from typing import Optional

from config import DEAD_ZONE_SIGNAL_THRESHOLD, DBSCAN_EPS_METERS, DBSCAN_MIN_SAMPLES

# Clustering libraries (DBSCAN, KMeans)
try:
    from sklearn.cluster import DBSCAN, KMeans
    CLUSTER_AVAILABLE = True
except ImportError:
    DBSCAN = None
    KMeans = None
    CLUSTER_AVAILABLE = False

# For ML classification (if you have a trained model)
try:
    import joblib
    ML_AVAILABLE = True
except ImportError:
    joblib = None
    ML_AVAILABLE = False

# For spatial interpolation (heatmap overlay)
try:
    from scipy.interpolate import Rbf, griddata
    SPATIAL_INTERP_AVAILABLE = True
except ImportError:
    SPATIAL_INTERP_AVAILABLE = False

import geopy.distance

class DeadZoneDetector:
    def __init__(
        self,
        static_threshold: Optional[float] = None,
        percentile_threshold: Optional[float] = None,
        dbscan_eps: Optional[float] = None,
        dbscan_min_samples: Optional[int] = None,
        ml_model_path: Optional[str] = None
    ):
        """
        Initialize DeadZoneDetector.
        
        :param static_threshold: Fixed threshold (e.g., -80 dBm). If None, uses config value.
        :param percentile_threshold: If set (e.g., 10 for bottom 10%), uses dynamic thresholding.
        :param dbscan_eps: DBSCAN epsilon (in meters). If None, uses config value.
        :param dbscan_min_samples: DBSCAN min_samples. If None, uses config value.
        :param ml_model_path: Path to a trained ML model for dead zone classification.
        """
        self.static_threshold = static_threshold if static_threshold is not None else DEAD_ZONE_SIGNAL_THRESHOLD
        self.percentile_threshold = percentile_threshold  # if set, dynamic thresholding is applied
        self.dbscan_eps_meters = dbscan_eps if dbscan_eps is not None else DBSCAN_EPS_METERS
        self.dbscan_min_samples = dbscan_min_samples if dbscan_min_samples is not None else DBSCAN_MIN_SAMPLES
        
        # This list can later store polygon definitions of dead zones for validation
        self.dead_zone_polygons = []
        self.last_update_time = time.time()
        
        # Load an ML model if available and provided
        self.ml_model = None
        if ML_AVAILABLE and ml_model_path:
            try:
                self.ml_model = joblib.load(ml_model_path)
                logging.info(f"Loaded ML dead zone model from {ml_model_path}")
            except Exception as e:
                logging.warning(f"Could not load ML dead zone model from {ml_model_path}: {e}")
                self.ml_model = None
    
    def _get_signal_threshold(self, df: pd.DataFrame) -> float:
        """
        Determine the threshold to use.
        If a percentile_threshold is specified, compute the threshold as the bottom percentile of signal_strength;
        otherwise, return the static threshold.
        """
        if df.empty:
            return self.static_threshold
        
        if self.percentile_threshold is not None:
            threshold = np.percentile(df['signal_strength'], self.percentile_threshold)
            logging.debug(f"Computed dynamic threshold: {threshold} using percentile: {self.percentile_threshold}")
            return threshold
        else:
            return self.static_threshold
    
    def incorporate_disconnections(self, df: pd.DataFrame, disconnection_strength: float = -95.0) -> pd.DataFrame:
        """
        Adjust rows with 'connection_status' equal to 'disconnected' so they have a very low signal_strength.
        This makes them show up as dead zones during clustering/interpolation.
        """
        if 'connection_status' not in df.columns:
            return df
        disc_mask = (df['connection_status'] == 'disconnected')
        df.loc[disc_mask, 'signal_strength'] = disconnection_strength
        return df
    
    def detect_dead_zones(self, signal_data: pd.DataFrame) -> pd.DataFrame:
        """
        Basic dead zone detection: Return data points with signal_strength below the threshold.
        """
        if signal_data.empty:
            return pd.DataFrame()
        
        threshold = self._get_signal_threshold(signal_data)
        dead_zone_points = signal_data[signal_data['signal_strength'] < threshold].copy()
        logging.info(f"Detected {len(dead_zone_points)} dead zone points using threshold {threshold}")
        return dead_zone_points
    
    def detect_dead_zones_clustering(self, signal_data: pd.DataFrame, method: str = 'dbscan', k: int = 3) -> pd.DataFrame:
        """
        Cluster weak signal points using either DBSCAN or KMeans.
        
        :param method: 'dbscan' (default) or 'kmeans'
        :param k: Number of clusters if using KMeans.
        :return: DataFrame of weak points with an added 'cluster' column.
        """
        if not CLUSTER_AVAILABLE:
            logging.warning("Clustering algorithms not available (scikit-learn missing).")
            return pd.DataFrame()
        
        if signal_data.empty:
            return pd.DataFrame()
        
        # Incorporate disconnection data so they are treated as weak signals
        signal_data = self.incorporate_disconnections(signal_data)
        
        threshold = self._get_signal_threshold(signal_data)
        weak_points = signal_data[signal_data['signal_strength'] < threshold].copy()
        if weak_points.empty:
            logging.info("No weak signal points found for clustering.")
            return pd.DataFrame()
        
        # Convert lat/lng to approximate x, y coordinates in meters
        lat0 = weak_points['lat'].median() if not weak_points['lat'].empty else 0.0
        def to_xy(row):
            x = row['lat'] * 111320  # ~111.32 km per degree latitude
            y = row['lng'] * 111320 * np.cos(np.radians(lat0))
            return pd.Series([x, y])
        XY = weak_points.apply(to_xy, axis=1)
        
        if method.lower() == 'dbscan':
            clustering = DBSCAN(eps=self.dbscan_eps_meters, min_samples=self.dbscan_min_samples)
            clusters = clustering.fit_predict(XY.values)
            weak_points['cluster'] = clusters
            n_clusters = len(set(clusters)) - (1 if -1 in clusters else 0)
            logging.info(f"DBSCAN clustering produced {n_clusters} clusters")
        elif method.lower() == 'kmeans':
            clustering = KMeans(n_clusters=k, random_state=42)
            clusters = clustering.fit_predict(XY.values)
            weak_points['cluster'] = clusters
            logging.info(f"KMeans clustering produced {k} clusters")
        else:
            logging.warning(f"Unknown clustering method '{method}', defaulting to DBSCAN.")
            clustering = DBSCAN(eps=self.dbscan_eps_meters, min_samples=self.dbscan_min_samples)
            clusters = clustering.fit_predict(XY.values)
            weak_points['cluster'] = clusters
        
        return weak_points
    
    def detect_dead_zones_ml(self, signal_data: pd.DataFrame) -> pd.DataFrame:
        """
        Use a pre-trained ML model to classify dead zones.
        The model should output 1 for a dead zone and 0 for normal.
        """
        if self.ml_model is None:
            logging.warning("ML model not loaded; cannot perform ML-based dead zone detection.")
            return pd.DataFrame()
        
        if signal_data.empty:
            return pd.DataFrame()
        
        signal_data = self.incorporate_disconnections(signal_data)
        # Example feature set: [signal_strength, lat, lng]
        features = signal_data[['signal_strength', 'lat', 'lng']].fillna(0)
        predictions = self.ml_model.predict(features)
        signal_data['ml_dead_zone'] = predictions
        dead_zone_ml = signal_data[signal_data['ml_dead_zone'] == 1].copy()
        logging.info(f"ML detection identified {len(dead_zone_ml)} dead zone points")
        return dead_zone_ml
    
    def generate_heatmap_overlay(self, signal_data: pd.DataFrame, grid_size: int = 50):
        """
        Generate an interpolated heatmap overlay using RBF interpolation.
        Returns a tuple (LAT, LNG, interpolated_signal, binary_mask), where:
          - LAT, LNG: meshgrid arrays of the grid coordinates
          - interpolated_signal: interpolated signal strength values on the grid
          - binary_mask: a mask (0 or 1) indicating regions below the threshold
        """
        if not SPATIAL_INTERP_AVAILABLE:
            logging.warning("Spatial interpolation (scipy) not available.")
            return None
        
        if signal_data.empty:
            logging.info("No signal data available for heatmap generation.")
            return None
        
        signal_data = self.incorporate_disconnections(signal_data)
        lats = signal_data['lat'].values
        lngs = signal_data['lng'].values
        signals = signal_data['signal_strength'].values
        
        min_lat, max_lat = lats.min(), lats.max()
        min_lng, max_lng = lngs.min(), lngs.max()
        lat_grid = np.linspace(min_lat, max_lat, grid_size)
        lng_grid = np.linspace(min_lng, max_lng, grid_size)
        LAT, LNG = np.meshgrid(lat_grid, lng_grid)
        
        # RBF interpolation with a linear function
        rbf = Rbf(lats, lngs, signals, function='linear')
        interpolated_signal = rbf(LAT, LNG)
        
        # Use the dynamic or static threshold on the interpolated data
        threshold = self._get_signal_threshold(signal_data)
        binary_mask = (interpolated_signal < threshold).astype(np.uint8)
        
        logging.info("Heatmap overlay generated.")
        return LAT, LNG, interpolated_signal, binary_mask
    
    def remove_stale_zones(self, new_data: pd.DataFrame):
        """
        Validate previously identified dead zones against new data.
        If new data within a dead zone shows strong signal, remove or update that zone.
        (This function is a stub and should be expanded with persistent zone tracking.)
        """
        logging.info("remove_stale_zones not implemented.")
        pass
