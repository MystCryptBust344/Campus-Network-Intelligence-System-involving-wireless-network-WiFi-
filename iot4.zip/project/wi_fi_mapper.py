# wi_fi_mapper.py

from imports import *
from device_tracker import DeviceTracker
from config import DEVICE_SCAN_INTERVAL, AP_SCAN_INTERVAL
from typing import Optional
from dash import dash_table
from deadzone_detector import DeadZoneDetector

try:
    from sklearn.cluster import KMeans, DBSCAN
    CLUSTERING_AVAILABLE = True
except ImportError:
    CLUSTERING_AVAILABLE = False

def generate_distinct_colors(n):
    colors = []
    for i in range(n):
        hue = i / max(1, n)
        saturation = 0.7
        value = 0.9
        rgb = colorsys.hsv_to_rgb(hue, saturation, value)
        colors.append(f'rgb({int(rgb[0]*255)}, {int(rgb[1]*255)}, {int(rgb[2]*255)})')
    return colors

class WiFiMapper:
    def __init__(self, config: dict = None):
        self.config = config or {}
        # Single DataFrame that holds both connected network data and visible AP data
        self.data = pd.DataFrame(
            columns=[
                'position', 'timestamp', 'strength', 'ssid', 'bssid',
                'connection_status', 'noise', 'channel', 'band'
            ]
        )
        self.positions = set()
        self.os_type = platform.system().lower()
        self.start_time = None
        self.current_ssid = None
        self.data_queue = queue.Queue()
        self.collection_active = False
        self.network_changes = []
        self.network_colors = {}
        self.last_connection_check = time.time()
        self.is_connected = True
        self.disconnection_periods = []
        self.current_disconnection_start = None
        self.device_tracker = DeviceTracker()
        self.device_scan_interval = DEVICE_SCAN_INTERVAL
        self.last_device_scan = 0
        self.device_colors = {}

        self.deadzone_detector = DeadZoneDetector()

    def get_current_ssid(self) -> Optional[str]:
        try:
            if self.os_type == 'windows':
                cmd = subprocess.run(
                    ['netsh', 'wlan', 'show', 'interfaces'],
                    capture_output=True,
                    text=True
                )
                match = re.search(r'SSID\s+:\s+(.+)\r?\n', cmd.stdout)
                return match.group(1).strip() if match else None
            else:
                # On Linux/mac, implement a different approach if needed
                pass
        except Exception as e:
            logging.error(f"Error getting SSID: {e}")
        return None

    def get_wifi_strength_windows(self):
        """
        Extract approximate dBm from 'netsh wlan show interfaces'.
        Now also parse the connected BSSID if available.
        """
        try:
            cmd = subprocess.run(
                ['netsh', 'wlan', 'show', 'interfaces'],
                capture_output=True,
                text=True
            )
            out = cmd.stdout
            # Signal in %
            match_signal = re.search(r'Signal\s+:\s+(\d+)%', out)
            if match_signal:
                percent = int(match_signal.group(1))
                strength = -100 + (percent * 0.7)
            else:
                strength = None

            # Parse BSSID
            match_bssid = re.search(r'BSSID\s+:\s+([0-9A-Fa-f:]+)', out)
            bssid = match_bssid.group(1).strip() if match_bssid else None

            # Channel
            match_channel = re.search(r'Channel\s+:\s+(\d+)\r?\n', out)
            channel = match_channel.group(1).strip() if match_channel else None

            # Radio type
            match_radio = re.search(r'Radio type\s+:\s+(\S+)\r?\n', out)
            radio_type = match_radio.group(1).strip() if match_radio else None
            if radio_type:
                rt_lower = radio_type.lower()
                if 'ac' in rt_lower or '5' in rt_lower:
                    band = "5GHz"
                elif 'n' in rt_lower:
                    band = "2.4/5GHz"
                else:
                    band = "2.4GHz"
            else:
                band = None

            if band and "5" in band:
                # If it's purely 5GHz or 2.4/5GHz, assume ~ -90
                noise = -90
            elif band == "2.4GHz":
                noise = -95
            else:
                noise = -92  # fallback if we can't parse the band
        
            return strength, noise, channel, band, bssid
        except Exception as e:
            logging.error(f"Error getting WiFi strength: {e}")
        return None, None, None, None, None

    def get_wifi_strength(self) -> tuple:
        """
        Returns (strength, noise, channel, band, bssid)
        Currently only implemented for Windows.
        """
        if self.os_type == 'windows':
            return self.get_wifi_strength_windows()
        else:
            logging.warning("get_wifi_strength() not implemented for non-Windows OS.")
            return None, None, None, None, None

    def check_internet_connection(self) -> bool:
        try:
            subprocess.run(
                ['ping', '-n' if self.os_type == 'windows' else '-c',
                 '1', '8.8.8.8'],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=1
            )
            return True
        except (subprocess.SubprocessError, subprocess.TimeoutExpired):
            return False

    def collect_data_continuously(self, position: str, duration_minutes: float = 5.0,
                                  interval_seconds: float = 1.0):
        self.collection_active = True
        self.start_time = time.time()
        end_time = self.start_time + (duration_minutes * 60)
        while time.time() < end_time and self.collection_active:
            current_time = time.time()
            # Check internet connection every 5 seconds
            if current_time - self.last_connection_check >= 5:
                previous_connection_state = self.is_connected
                self.is_connected = self.check_internet_connection()
                self.last_connection_check = current_time
                if previous_connection_state and not self.is_connected:
                    self.current_disconnection_start = current_time
                elif not previous_connection_state and self.is_connected:
                    if self.current_disconnection_start:
                        self.disconnection_periods.append({
                            'start': self.current_disconnection_start,
                            'end': current_time,
                            'duration': current_time - self.current_disconnection_start
                        })
                        self.current_disconnection_start = None

            if self.is_connected:
                current_ssid = self.get_current_ssid()
                strength, noise, channel, band, bssid = self.get_wifi_strength()

                # Create a color if new SSID
                if current_ssid and current_ssid not in self.network_colors:
                    new_colors = generate_distinct_colors(len(self.network_colors) + 1)
                    self.network_colors[current_ssid] = new_colors[-1]

                # Detect network changes
                if self.current_ssid is not None and current_ssid != self.current_ssid:
                    self.network_changes.append({
                        'timestamp': current_time,
                        'position': position,
                        'old_network': self.current_ssid,
                        'new_network': current_ssid,
                        'strength': strength if strength else None,
                        'change_number': len(self.network_changes) + 1
                    })
                    logging.info(
                        f"Network change #{len(self.network_changes)}: {self.current_ssid} -> {current_ssid}"
                    )

                self.current_ssid = current_ssid

                data_point = {
                    'position': position,
                    'timestamp': current_time,
                    'strength': strength if strength is not None else -90,
                    'ssid': current_ssid,
                    'bssid': bssid,
                    'connection_status': 'connected',
                    'noise': noise,
                    'channel': channel,
                    'band': band
                }
                self.data_queue.put(data_point)
            else:
                data_point = {
                    'position': position,
                    'timestamp': current_time,
                    'strength': None,
                    'ssid': None,
                    'bssid': None,
                    'connection_status': 'disconnected',
                    'noise': None,
                    'channel': None,
                    'band': None
                }
                self.data_queue.put(data_point)

            # Periodically scan devices on the network
            if current_time - self.last_device_scan >= self.device_scan_interval:
                self.last_device_scan = current_time
                self.device_tracker.scan_network_devices()

            time.sleep(interval_seconds)

        self.collection_active = False

    def scan_visible_networks(self):
        """
        Scan all visible WiFi networks (BSSIDs) on Windows:
            'netsh wlan show networks mode=bssid'
        Append each discovered BSSID to the main self.data with connection_status='visible'.
        """
        timestamp = time.time()
        if self.os_type == 'windows':
            try:
                cmd = subprocess.run(
                    ['netsh', 'wlan', 'show', 'networks', 'mode=bssid'],
                    capture_output=True,
                    text=True,
                    timeout=5
                )
                output = cmd.stdout
                if not output.strip():
                    logging.warning("No output from 'netsh wlan show networks'. Run as Admin or ensure Wi-Fi adapter is enabled.")
                else:
                    logging.info("Scanning visible networks: netsh command output found.")
                # Split on "SSID x : "
                networks = re.split(r'SSID\s+\d+\s*:\s', output)
                for net_block in networks:
                    net_block = net_block.strip()
                    if not net_block:
                        continue
                    lines = net_block.split('\n')
                    ssid_line = lines[0].strip() if lines else "Unknown"
                    ssid = ssid_line

                    bssid_matches = re.finditer(
                        r'BSSID\s+(\d+)\s*:\s*([0-9a-fA-F:]+).*?Signal\s*:\s*(\d+)%.*?Channel\s*:\s*(\d+)',
                        net_block, flags=re.DOTALL
                    )
                    found_any_bssid = False
                    for match in bssid_matches:
                        found_any_bssid = True
                        bssid = match.group(2).lower()
                        signal_percent = int(match.group(3))
                        channel = match.group(4)
                        rssi = -100 + (signal_percent * 0.7)

                        try:
                            ch_int = int(channel)
                            if ch_int > 14:
                                band = "5GHz"
                            else:
                                band = "2.4GHz"
                        except:
                            band = None
                        
                        if band == "5GHz":
                            noise = -90
                        else:
                            # If channel <= 14 or unknown: assume 2.4GHz ~ -95
                            noise = -95

                        # Insert a row into self.data with 'visible' status
                        row = {
                            'position': 'scan',
                            'timestamp': timestamp,
                            'strength': rssi,
                            'ssid': ssid,
                            'bssid': bssid,
                            'connection_status': 'visible',
                            'noise': noise,
                            'channel': channel,
                            'band': band
                        }
                        self.data_queue.put(row)

                    if not found_any_bssid:
                        logging.debug(f"No BSSID found in block for SSID: {ssid_line}")
            except Exception as e:
                logging.error(f"Error scanning visible networks (Windows): {e}")
        else:
            logging.warning("scan_visible_networks() not implemented for non-Windows OS.")

    def scan_visible_networks_continuously(self, interval_seconds: float):
        while self.collection_active:
            self.scan_visible_networks()
            time.sleep(interval_seconds)

    def create_dash_app(self, duration_minutes: float = 5.0, interval_seconds: float = 1.0):
        # Allow dash to handle multi-output even if some components are not present at first
        app = dash.Dash(__name__, suppress_callback_exceptions=True)

        app.layout = html.Div([
            html.H1('Real-time WiFi Signal Strength Monitor'),
            dcc.Graph(
                id='live-3d-graph',
                style={'height': '60vh'},
                config={'scrollZoom': True, 'displayModeBar': True}
            ),
            html.H2('Device Distance Tracking (2D Map)'),
            dcc.Graph(
                id='device-distance-map',
                style={'height': '40vh'},
                config={'scrollZoom': True, 'displayModeBar': True}
            ),
            html.H2('Device Distance Clustering'),
            dcc.Graph(
                id='device-cluster-graph',
                style={'height': '40vh'},
                config={'scrollZoom': True, 'displayModeBar': True}
            ),
            html.H2('Dead Zone Detection'),
            dcc.Graph(
                id='dead-zone-graph',
                style={'height': '40vh'},
                config={'scrollZoom': True, 'displayModeBar': True}
            ),
            dcc.Interval(
                id='interval-component',
                interval=int(interval_seconds * 1000),
                n_intervals=0
            ),
            html.Div([
                html.Div([
                    html.H3('Network Changes'),
                    html.Div(id='network-changes')
                ], style={'flex': '1', 'margin-right': '20px'}),
                html.Div([
                    html.H3('Connection Status'),
                    html.Div(id='connection-status')
                ], style={'flex': '1', 'margin-right': '20px'}),
                html.Div([
                    html.H3('Connected Devices'),
                    html.Div(id='device-info')
                ], style={'flex': '1'})
            ], style={'display': 'flex', 'margin-top': '20px'}),
            
            html.H2('All Collected Data'),
            dash_table.DataTable(
                id='data-table',
                columns=[{"name": c, "id": c} for c in self.data.columns],
                data=[]
            )
        ])

        @app.callback(
            Output('live-3d-graph', 'figure'),
            Output('device-distance-map', 'figure'),
            Output('device-cluster-graph', 'figure'),
            Output('dead-zone-graph', 'figure'),
            Output('network-changes', 'children'),
            Output('connection-status', 'children'),
            Output('device-info', 'children'),
            Output('data-table', 'data'),
            Input('interval-component', 'n_intervals')
        )
        def update_graphs(n_intervals):
            # Drain the data_queue
            while not self.data_queue.empty():
                data_point = self.data_queue.get()
                new_df = pd.DataFrame([data_point])
                self.data = pd.concat([self.data, new_df], ignore_index=True)

            if self.data.empty:
                empty_fig = go.Figure()
                empty_fig.update_layout(title="No data yet")
                return (
                    empty_fig,
                    empty_fig,
                    empty_fig,
                    empty_fig,
                    "No data yet",
                    "Waiting for data...",
                    "No devices detected",
                    []
                )

            # 1) WiFi Signal Strength Graph
            fig_signal = go.Figure()
            plot_df = self.data.copy()
            plot_df['timestamp_dt'] = plot_df['timestamp'].apply(
                lambda t: datetime.fromtimestamp(float(t))
            )
            for ssid in plot_df['ssid'].unique():
                mask = (plot_df['ssid'] == ssid) & (plot_df['connection_status'] == 'connected')
                df_network = plot_df[mask]
                name_ssid = "No SSID" if ssid is None else f"Network: {ssid}"
                if not df_network.empty:
                    color_for_ssid = self.network_colors.get(ssid, 'blue')
                    fig_signal.add_trace(go.Scatter(
                        x=df_network['timestamp_dt'],
                        y=df_network['strength'].fillna(-90),
                        mode='lines+markers',
                        name=name_ssid,
                        line=dict(color=color_for_ssid, width=2),
                        marker=dict(size=5)
                    ))
            
            # Mark network changes with expanded text
            if self.network_changes:
                change_times = [datetime.fromtimestamp(ch['timestamp']) for ch in self.network_changes]
                change_strengths = [
                    ch['strength'] if ch['strength'] is not None else -90 
                    for ch in self.network_changes
                ]
                change_labels = [
                    (
                        f"Change #{ch['change_number']}\n"
                        f"{ch['old_network']} → {ch['new_network']}\n"
                        f"Strength: {ch['strength']:.1f} dBm"
                        if ch['strength'] is not None else ""
                    )
                    for ch in self.network_changes
                ]
                fig_signal.add_trace(go.Scatter(
                    x=change_times,
                    y=change_strengths,
                    mode='markers+text',
                    name='Network Changes',
                    text=change_labels,
                    textposition='top center',
                    marker=dict(size=10, color='yellow', symbol='diamond', line=dict(color='black', width=1))
                ))

            # Disconnection shading
            for period in self.disconnection_periods:
                start_dt = datetime.fromtimestamp(period['start'])
                end_dt = datetime.fromtimestamp(period['end'])
                fig_signal.add_shape(
                    type="rect",
                    xref="x", yref="paper",
                    x0=start_dt, x1=end_dt,
                    y0=0, y1=1,
                    fillcolor="red", opacity=0.2, line_width=0,
                    layer="below",
                )
            
            fig_signal.update_layout(
                title='Real-time WiFi Signal Strength',
                xaxis_title='Time',
                yaxis_title='Signal Strength (dBm)',
                yaxis=dict(range=[-90, -30]),
                showlegend=True,
                legend=dict(x=0.01, y=0.99),
                uirevision='true'
            )
            # Force smaller intervals on the x-axis
            fig_signal.update_xaxes(
                type='date',
                tickformat='%H:%M:%S',
                dtick=30000  # ~30-second spacing; adjust as needed
            )

            # 2) Device Distance Map (2D)
            fig_device = go.Figure()
            host_lat, host_lng = self.device_tracker.current_location or (0, 0)
            fig_device.add_trace(go.Scattergeo(
                lat=[host_lat],
                lon=[host_lng],
                mode='markers+text',
                marker=dict(size=14, symbol='star'),
                text=["Your Device"],
                textposition='top center',
                name='Your Device'
            ))

            for device_id in self.device_tracker.devices:
                if device_id not in self.device_colors:
                    new_colors = generate_distinct_colors(len(self.device_colors) + 1)
                    self.device_colors[device_id] = new_colors[-1]

            df_devices = pd.DataFrame(self.device_tracker.device_distances)
            df_devices['time_str'] = df_devices['time'].apply(
                lambda t: datetime.fromtimestamp(float(t)).strftime('%H:%M:%S')
            )
            device_data = {}
            for idx, row in df_devices.iterrows():
                dmac = row['device_id']
                if dmac not in device_data:
                    device_data[dmac] = []
                device_data[dmac].append(row)

            for device_id, entries in device_data.items():
                entries.sort(key=lambda x: x['time'])
                lats = [e['lat'] for e in entries if e['lat'] is not None]
                lngs = [e['lng'] for e in entries if e['lng'] is not None]
                color = self.device_colors[device_id]
                device_name = f"Device {device_id[-5:]}"
                if len(lats) > 1:
                    fig_device.add_trace(go.Scattergeo(
                        lat=lats,
                        lon=lngs,
                        mode='lines',
                        line=dict(width=2, color=color),
                        name=f"{device_name} Path"
                    ))
                last_pos = entries[-1]
                if last_pos['lat'] is not None and last_pos['lng'] is not None:
                    disp_text = (
                        f"{device_name}<br>"
                        f"Dist: {last_pos['distance'] if last_pos['distance'] else 0:.1f}m<br>"
                        f"{last_pos['connection_status']}"
                    )
                    fig_device.add_trace(go.Scattergeo(
                        lat=[last_pos['lat']],
                        lon=[last_pos['lng']],
                        mode='markers+text',
                        text=[disp_text],
                        textposition='top center',
                        marker=dict(size=8, color=color, symbol='circle'),
                        name=device_name
                    ))
                    # Dashed line from host to device
                    fig_device.add_trace(go.Scattergeo(
                        lat=[host_lat, last_pos['lat']],
                        lon=[host_lng, last_pos['lng']],
                        mode='lines',
                        line=dict(width=1, color=color, dash='dot'),
                        name=f"Distance to {device_name}"
                    ))

            fig_device.update_layout(
                title='Connected Device Distance Map',
                geo=dict(
                    scope='world',
                    projection_type='equirectangular',
                    showland=True,
                    landcolor='rgb(217, 217, 217)',
                    countrycolor='rgb(255, 255, 255)',
                    showocean=True,
                    oceancolor='rgb(208, 242, 255)',
                    resolution=50
                ),
                height=500,
                showlegend=True
            )

            all_lats = [host_lat]
            all_lngs = [host_lng]
            for dmac, info in self.device_tracker.devices.items():
                if info['location']:
                    all_lats.append(info['location'][0])
                    all_lngs.append(info['location'][1])
            if len(all_lats) > 1:
                min_lat, max_lat = min(all_lats), max(all_lats)
                min_lng, max_lng = min(all_lngs), max(all_lngs)
                lat_pad = (max_lat - min_lat) * 0.2
                lng_pad = (max_lng - min_lng) * 0.2
                center_lat = (min_lat + max_lat) / 2
                center_lng = (min_lng + max_lng) / 2
                fig_device.update_geos(
                    center=dict(lat=center_lat, lon=center_lng),
                    projection_scale=1,
                    lataxis_range=[min_lat - lat_pad, max_lat + lat_pad],
                    lonaxis_range=[min_lng - lng_pad, max_lng + lng_pad]
                )

            # 3) Device Clustering
            fig_cluster = go.Figure()
            if CLUSTERING_AVAILABLE and not df_devices.empty:
                X = df_devices[['lat','lng']].dropna()
                if not X.empty:
                    kmeans = KMeans(n_clusters=3, random_state=42).fit(X)
                    labels = kmeans.labels_
                    X['cluster'] = labels
                    for cluster_id in sorted(X['cluster'].unique()):
                        sub = X[X['cluster'] == cluster_id]
                        fig_cluster.add_trace(go.Scatter(
                            x=sub['lat'],
                            y=sub['lng'],
                            mode='markers',
                            marker=dict(size=8),
                            name=f'Cluster {cluster_id}'
                        ))
                    centers = kmeans.cluster_centers_
                    fig_cluster.add_trace(go.Scatter(
                        x=centers[:,0],
                        y=centers[:,1],
                        mode='markers',
                        marker=dict(size=12, symbol='x', color='red'),
                        name='Centers'
                    ))
                    fig_cluster.update_layout(
                        title='Clusters of Devices (lat vs. lng)',
                        xaxis_title='Latitude',
                        yaxis_title='Longitude',
                        showlegend=True
                    )
                else:
                    fig_cluster.update_layout(title='No valid lat/lng for clustering')
            else:
                fig_cluster.update_layout(title='Clustering unavailable or no device data yet')

            # 4) Dead Zone Detection
            dead_zone_fig = go.Figure()
            if not df_devices.empty:
                detected = self.deadzone_detector.detect_dead_zones_clustering(df_devices)
                if not detected.empty:
                    for cluster_id in sorted(detected['cluster'].unique()):
                        if cluster_id == -1:
                            sub = detected[detected['cluster'] == -1]
                            cname = 'Noise'
                        else:
                            sub = detected[detected['cluster'] == cluster_id]
                            cname = f'Dead Zone #{cluster_id}'
                        dead_zone_fig.add_trace(go.Scatter(
                            x=sub['lat'],
                            y=sub['lng'],
                            mode='markers',
                            marker=dict(size=8),
                            name=cname
                        ))
                    dead_zone_fig.update_layout(
                        title='Dead Zone Clusters (Weak Signals)',
                        xaxis_title='Latitude',
                        yaxis_title='Longitude'
                    )
                else:
                    dead_zone_fig.update_layout(title='No dead zones found (no weak signals)')
            else:
                dead_zone_fig.update_layout(title='No device data for dead zone detection')

            # 5) Build “network changes” panel
            network_changes_text = [
                html.P(
                    [
                        f"Change #{change['change_number']} at ",
                        html.B(datetime.fromtimestamp(change['timestamp']).strftime('%H:%M:%S')),
                        f": {change['old_network']} → {change['new_network']} ",
                        html.Br(),
                        f"Position: {change['position']}, Strength: {change['strength']} dBm"
                    ],
                    style={'color': 'black', 'backgroundColor': '#fff3cd', 'padding': '10px',
                           'borderRadius': '5px', 'marginBottom': '5px'}
                )
                for change in self.network_changes
            ]

            # 6) Build “connection status” panel
            connection_status = []
            for period in self.disconnection_periods:
                connection_status.append(
                    html.P(
                        [
                            html.B("Disconnection detected: "),
                            f"Duration: {period['duration']:.1f} seconds",
                            html.Br(),
                            f"From: {datetime.fromtimestamp(period['start']).strftime('%H:%M:%S')}",
                            html.Br(),
                            f"To: {datetime.fromtimestamp(period['end']).strftime('%H:%M:%S')}"
                        ],
                        style={'color': 'white', 'backgroundColor': '#dc3545', 'padding': '10px',
                               'borderRadius': '5px', 'marginBottom': '5px'}
                    )
                )
            if not self.is_connected and self.current_disconnection_start:
                current_duration = time.time() - self.current_disconnection_start
                connection_status.append(
                    html.P(
                        [
                            html.B("Currently Disconnected"),
                            html.Br(),
                            f"Duration: {current_duration:.1f} seconds",
                            html.Br(),
                            f"Since: {datetime.fromtimestamp(self.current_disconnection_start).strftime('%H:%M:%S')}"
                        ],
                        style={'color': 'white', 'backgroundColor': '#dc3545', 'padding': '10px',
                               'borderRadius': '5px', 'marginBottom': '5px'}
                    )
                )

            # 7) Build device info text
            device_info = []
            for device_id, device in self.device_tracker.devices.items():
                st = device['signal_strength']
                device_info.append(
                    html.P(
                        [
                            html.B(f"Device {device_id[-8:]}"),
                            html.Br(),
                            f"IP: {device['ip']}",
                            html.Br(),
                            f"Distance: {device['distance']:.2f} m",
                            html.Br(),
                            f"Signal: {st if st is not None else 'Unknown'} dBm",
                            html.Br(),
                            f"Status: {device['connection_status']}",
                            html.Br(),
                            f"Location: {device['location'][0]:.5f}, {device['location'][1]:.5f}"
                        ],
                        style={'color': 'black', 'backgroundColor': '#e9ecef', 'padding': '10px',
                               'borderRadius': '5px', 'marginBottom': '5px'}
                    )
                )
            if not device_info:
                device_info = [html.P("No devices detected yet")]

            # 8) Prepare single data table
            table_df = self.data.copy()
            table_df['timestamp'] = table_df['timestamp'].apply(
                lambda t: datetime.fromtimestamp(float(t)).strftime('%Y-%m-%d %H:%M:%S')
                if not pd.isnull(t) else ''
            )
            data_table = table_df.to_dict('records')

            return (
                fig_signal,
                fig_device,
                fig_cluster,
                dead_zone_fig,
                html.Div(network_changes_text),
                html.Div(connection_status),
                html.Div(device_info),
                data_table
            )

        return app
