# distance_estimator.py

import math
import numpy as np
import time
import logging
from filterpy.kalman import KalmanFilter

# BEGIN ADVANCED CHANGE
# For ML loading (scikit-learn). If you are not using scikit-learn, adapt accordingly.
try:
    import joblib
except ImportError:
    joblib = None

from config import (
    ML_MODEL_PATH,
    GP_MODEL_PATH,
    ENV_CLASSES
)
# END ADVANCED CHANGE


class AdaptiveFilter:
    """
    Manages outlier rejection, median smoothing, and an adaptive KalmanFilter
    for each device. Returns a 'cleaned' RSSI. If you wish, you can add
    a particle filter path or multi-sensor data fusion here as well.
    """
    def __init__(self, window_size=5, outlier_threshold=20.0):
        # How many recent RSSI readings we keep for median/mean filtering
        self.window_size = window_size
        # Single-jump outlier detection in dB
        self.outlier_threshold = outlier_threshold
        # Per-device state: { device_id: {'kf': KalmanFilter, 'initialized': bool, 'window': [...], 'last_clean': float}}
        self.filters = {}

    def _create_kalman_filter(self, initial_rssi=-50.0):
        kf = KalmanFilter(dim_x=2, dim_z=1)
        # State transition matrix
        kf.F = np.array([[1.0, 1.0],
                         [0.0, 1.0]])
        # Measurement function
        kf.H = np.array([[1.0, 0.0]])
        # Measurement noise - can be tuned or adapted
        kf.R = np.array([[6.0]])
        # Process noise
        kf.Q = np.array([[0.01, 0.01],
                         [0.01, 0.1]])
        # Initial state
        kf.x = np.array([[initial_rssi], [0.0]])
        # Initial state covariance
        kf.P = np.array([[10.0, 0.0],
                         [0.0, 1.0]])
        return kf

    def update_rssi(self, device_id, new_rssi):
        """
        Main entry: pass in raw RSSI, get back a filtered RSSI.
        """
        if device_id not in self.filters:
            # Initialize new filter state for this device
            self.filters[device_id] = {
                'kf': self._create_kalman_filter(new_rssi),
                'initialized': True,
                'window': [new_rssi],
                'last_clean': new_rssi,
                'last_update': time.time()
            }
            return new_rssi

        fstate = self.filters[device_id]
        rssi_window = fstate['window']

        # Detect big outliers relative to last "clean" measurement
        if abs(new_rssi - fstate['last_clean']) > self.outlier_threshold:
            # If it's a one-off, we skip or clamp it, but if it's consistently big, keep it
            # For simplicity, let's just clamp to outlier_threshold distance from last_clean
            new_rssi = fstate['last_clean'] + self.outlier_threshold * np.sign(new_rssi - fstate['last_clean'])

        # Add to sliding window
        rssi_window.append(new_rssi)
        if len(rssi_window) > self.window_size:
            rssi_window.pop(0)

        # Median (or mean) filter - remove random spikes
        cleaned_rssi = float(np.median(rssi_window))

        # Kalman filter update
        kf = fstate['kf']
        kf.predict()
        # Check residual to adapt Q if needed
        predicted = float(kf.x[0, 0])
        residual = abs(cleaned_rssi - predicted)
        if residual > 5.0:
            # Increase process noise if we have a big mismatch
            kf.Q = np.array([[0.1, 0.01],
                             [0.01, 0.2]])
        else:
            # Gradually revert Q to a smaller baseline
            kf.Q = np.array([[0.01, 0.01],
                             [0.01, 0.1]])
        kf.update(np.array([cleaned_rssi]))

        final_rssi = float(kf.x[0, 0])

        # Store back
        fstate['last_clean'] = final_rssi
        return final_rssi


# BEGIN ADVANCED CHANGE
class MLDistanceModel:
    """
    Placeholder wrapper for a scikit-learn model used to predict distance from RSSI features.
    You must train and save an actual model to ML_MODEL_PATH for this to be functional.
    """
    def __init__(self, model_path):
        self.model = None
        if joblib and model_path:
            try:
                self.model = joblib.load(model_path)
                logging.info(f"Loaded ML distance model from {model_path}")
            except Exception as e:
                logging.warning(f"Could not load ML model from {model_path}: {e}")
        else:
            logging.warning("joblib not available or no model path specified. MLDistanceModel is inoperative.")

    def predict_distance(self, rssi, variance, environment):
        if self.model is None:
            # fallback to a simple formula or dummy
            return max(0.1, 10.0 - 0.2 * (rssi + 50))
        # Example feature vector: [rssi, variance, environment_one_hot...]
        # For simplicity, environment is turned into an index. 
        env_index = ENV_CLASSES.index(environment) if environment in ENV_CLASSES else 0
        X = np.array([[rssi, variance, env_index]])
        dist = self.model.predict(X)
        return float(dist[0])


class GPDistanceModel:
    """
    Placeholder for a Gaussian Process regressor.
    Could be scikit-learn's GaussianProcessRegressor or GPyTorch, etc.
    """
    def __init__(self, model_path):
        self.gp_model = None
        if joblib and model_path:
            try:
                self.gp_model = joblib.load(model_path)
                logging.info(f"Loaded GP distance model from {model_path}")
            except Exception as e:
                logging.warning(f"Could not load GP model from {model_path}: {e}")
        else:
            logging.warning("joblib not available or no GP model path specified. GPDistanceModel is inoperative.")

    def predict_distance(self, rssi, variance, environment):
        if self.gp_model is None:
            # fallback
            return max(0.1, 10.0 - 0.25 * (rssi + 50))
        env_index = ENV_CLASSES.index(environment) if environment in ENV_CLASSES else 0
        X = np.array([[rssi, variance, env_index]])
        dist, std = self.gp_model.predict(X, return_std=True)
        # You could do something with the std for confidence intervals
        return float(dist[0])


class EnvironmentClassifier:
    """
    A simple environment classification stub. In reality, you'd implement
    a better approach: look at RSSI variance, device movement, multi-AP signals, etc.
    Or load a pre-trained classifier (like we do for distance).
    """
    def predict_environment(self, recent_rssi_window):
        if len(recent_rssi_window) < 3:
            return 'indoor'
        avg_rssi = np.mean(recent_rssi_window)
        var_rssi = np.var(recent_rssi_window)
        # Some naive logic
        if avg_rssi > -45:
            return 'indoor'
        elif var_rssi > 50:
            return 'nlos'  # Just a silly example
        else:
            return 'outdoor_open'
# END ADVANCED CHANGE


class EnhancedDistanceEstimator:
    """Advanced WiFi distance estimation using various path-loss models and optional shadow fading."""
    
    # Added environment_mode='auto' to optionally do environment classification
    def __init__(self, environment='indoor', environment_mode='manual'):
        """
        Initialize the distance estimator with environment-specific parameters.
        
        Args:
            environment (str): 'indoor', 'outdoor_urban', 'outdoor_suburban', 'outdoor_open', etc.
            environment_mode (str): 'manual' or 'auto'. If 'auto', environment classification will be done.
        """
        self.environment = environment
        self.environment_mode = environment_mode

        # We add a special "indoor_5ghz" environment if we detect 5GHz
        self.path_loss_exponents = {
            'indoor': 3.0,
            'indoor_5ghz': 3.3,   # Example tweak for 5 GHz indoors
            'outdoor_urban': 2.7,
            'outdoor_suburban': 2.0,
            'outdoor_open': 2.0,
            'nlos': 3.5,  # Extra example for non-line-of-sight
        }
        
        # Reference RSSI at 1m distance
        self.reference_rssi = {
            'indoor': -40,
            'indoor_5ghz': -48,
            'outdoor_urban': -35,
            'outdoor_suburban': -30,
            'outdoor_open': -28,
            'nlos': -45
        }
        
        # Shadow fading std dev by environment
        self.shadow_std_dev = {
            'indoor': 5.0,
            'indoor_5ghz': 6.0,
            'outdoor_urban': 4.0,
            'outdoor_suburban': 3.0,
            'outdoor_open': 2.0,
            'nlos': 6.0
        }
        
        # Frequency in MHz (typical 2.4GHz). We might override if band=5GHz
        self.frequency = 2400
        
        # Shadow offsets, stored per-device so each device sees consistent random fade
        self.shadow_offsets = {}
        self.shadow_update_interval = 60  # seconds

        # BEGIN ADVANCED CHANGE
        # ML + Gaussian Process stubs
        self.ml_model = MLDistanceModel(ML_MODEL_PATH)
        self.gp_model = GPDistanceModel(GP_MODEL_PATH)
        self.env_classifier = EnvironmentClassifier()
        # Store recent RSSI windows for environment classification
        self.device_rssi_window = {}
        # END ADVANCED CHANGE

    def set_environment_from_band(self, band):
        """
        If we detect '5GHz', set environment='indoor_5ghz' or something custom.
        Otherwise leave as is, or set environment='indoor'.
        """
        if band and '5' in band:
            self.environment = 'indoor_5ghz'
            self.frequency = 5200  # example for 5GHz
        else:
            # fallback; assume 2.4
            self.environment = 'indoor'
            self.frequency = 2400

    def apply_shadow_fading(self, distance, device_id=None):
        """
        Apply a shadow-fading offset to the distance, with a consistent offset per device.
        """
        sigma = self.shadow_std_dev.get(self.environment, 5.0)
        current_time = time.time()
        
        if device_id is not None:
            if device_id in self.shadow_offsets:
                offset, last_update = self.shadow_offsets[device_id]
                if current_time - last_update > self.shadow_update_interval:
                    offset = np.random.normal(0, sigma)
                    self.shadow_offsets[device_id] = (offset, current_time)
            else:
                offset = np.random.normal(0, sigma)
                self.shadow_offsets[device_id] = (offset, current_time)
        else:
            offset = np.random.normal(0, sigma)
        
        fading_factor = 10 ** (offset / 10)
        return distance * fading_factor

    def free_space_path_loss(self, rssi):
        """
        FSPL(dB) = 20*log10(d) + 20*log10(f_MHz) + 32.44
        => d(km) = 10^((FSPL - 32.44 - 20 log10(f_MHz))/20)
        """
        transmit_power = 20  # dBm, example
        freq_mhz = self.frequency
        
        fspl = transmit_power - rssi
        exponent = (fspl - 32.44 - 20 * math.log10(freq_mhz)) / 20
        distance_km = 10 ** exponent
        return distance_km * 1000

    def log_distance_path_loss(self, rssi):
        """
        Calculate distance using the log-distance path loss model.
        """
        n = self.path_loss_exponents.get(self.environment, 3.0)
        rssi_d0 = self.reference_rssi.get(self.environment, -40)
        
        exponent = (rssi_d0 - rssi) / (10.0 * n)
        distance = 1.0 * (10.0 ** exponent)
        return distance

    def hata_model(self, rssi):
        """
        Simplified Hata model for outdoor areas. If environment is not outdoor,
        fallback to log_distance.
        """
        if not self.environment.startswith('outdoor'):
            # fallback
            return self.log_distance_path_loss(rssi)

        hb = 10.0   # Base station antenna height, example
        hm = 1.5  # Mobile antenna height
        f = self.frequency
        tx_power = 20.0  # dBm
        path_loss = tx_power - rssi
        
        import math
        a_hm = 3.2 * (math.log10(11.75 * hm))**2 - 4.97
        L_urban = 69.55 + 26.16 * math.log10(f) - 13.82 * math.log10(hb) - a_hm
        distance_km = 10 ** ((path_loss - L_urban) / (44.9 - 6.55 * math.log10(hb)))
        return distance_km * 1000.0

    def estimate_distance(self, rssi, model='log_distance', apply_shadowing=False, device_id=None, band=None):
        """
        Main distance estimation method. Optionally do shadow fading.
        You can also pass 'band' here if you want to override environment.
        """
        # BEGIN ADVANCED CHANGE
        # Maintain a short RSSI window for environment classification if environment_mode='auto'
        if device_id is not None:
            if device_id not in self.device_rssi_window:
                self.device_rssi_window[device_id] = []
            # Keep a small rolling window
            self.device_rssi_window[device_id].append(rssi)
            if len(self.device_rssi_window[device_id]) > 10:
                self.device_rssi_window[device_id].pop(0)

            if self.environment_mode == 'auto':
                # Classify environment from the RSSI window
                predicted_env = self.env_classifier.predict_environment(self.device_rssi_window[device_id])
                # Overwrite self.environment if you want dynamic environment
                self.environment = predicted_env
        # END ADVANCED CHANGE

        # If user passed band, override environment accordingly
        if band is not None:
            self.set_environment_from_band(band)

        if model == 'free_space':
            distance = self.free_space_path_loss(rssi)
        elif model == 'log_distance':
            distance = self.log_distance_path_loss(rssi)
        elif model == 'hata':
            distance = self.hata_model(rssi)
        elif model == 'ensemble':
            # Weighted combination
            models = [self.log_distance_path_loss(rssi),
                      self.free_space_path_loss(rssi)]
            if self.environment.startswith('outdoor'):
                models.append(self.hata_model(rssi))
            
            # Weight them
            if self.environment == 'indoor' or self.environment == 'indoor_5ghz':
                weights = [0.6, 0.4]  # no Hata for indoor
            else:
                # Outdoor or nlos
                weights = [0.4, 0.3, 0.3]
            
            # Trim weights if we only have 2 models
            weights = weights[:len(models)]
            total_w = sum(weights)
            weights = [w / total_w for w in weights]
            distance = sum(d * w for d, w in zip(models, weights))
        # BEGIN ADVANCED CHANGE
        elif model == 'ml':
            # Example ML approach
            # We might pass variance of the last window as a feature
            var_rssi = np.var(self.device_rssi_window[device_id]) if device_id else 0.0
            distance = self.ml_model.predict_distance(rssi, var_rssi, self.environment)

        elif model == 'gaussian_process':
            var_rssi = np.var(self.device_rssi_window[device_id]) if device_id else 0.0
            distance = self.gp_model.predict_distance(rssi, var_rssi, self.environment)
        # END ADVANCED CHANGE
        else:
            distance = self.log_distance_path_loss(rssi)

        if apply_shadowing:
            distance = self.apply_shadow_fading(distance, device_id=device_id)
        
        # clamp for safety
        distance = max(0.1, min(10000, distance))
        return distance
