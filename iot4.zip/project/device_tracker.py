# device_tracker.py

from imports import *
from distance_estimator import EnhancedDistanceEstimator, AdaptiveFilter
from config import DEFAULT_COORDINATES, DEFAULT_ENVIRONMENT

class DeviceTracker:
    """Enhanced DeviceTracker with improved distance estimation & adaptive filtering."""
    def __init__(self):
        self.devices = {}
        self.device_distances = []
        self.current_location = None
        self.w = None
        try:
            import wmi
            self.w = wmi.WMI()
        except ImportError:
            print("WMI module not available - some Windows-specific features will be limited")
        
        # BEGIN ADVANCED CHANGE
        # We can pass environment='auto' to let the EnhancedDistanceEstimator do environment classification.
        # Or keep a default environment (e.g., 'indoor').
        self.distance_estimator = EnhancedDistanceEstimator(environment=DEFAULT_ENVIRONMENT, environment_mode='auto')
        # END ADVANCED CHANGE

        # Instead of manual smoothing, we now rely on an AdaptiveFilter
        # that we call for each new RSSI measurement.
        self.adaptive_filter = AdaptiveFilter(window_size=5, outlier_threshold=20.0)

        # Retain a small history if you want it for analysis
        self.device_rssi_history = {}
        self.max_history_len = 50

        self.previous_scan_macs = set()

    def set_environment(self, environment):
        """
        Let user manually set environment (if not deducing from band).
        """
        if environment in ['indoor', 'indoor_5ghz', 'outdoor_urban', 'outdoor_suburban', 'outdoor_open']:
            self.distance_estimator.environment = environment
            return True
        return False

    def get_current_location(self):
        """Get current device geolocation using IP-based geolocation (or fallback)."""
        try:
            response = requests.get('https://ipinfo.io/json')
            if response.status_code == 200:
                data = response.json()
                if 'loc' in data:
                    lat, lng = map(float, data['loc'].split(','))
                    self.current_location = (lat, lng)
                    return (lat, lng)
        except Exception as e:
            logging.error(f"Error getting geolocation: {e}")
        
        # Fallback
        if not self.current_location:
            self.current_location = DEFAULT_COORDINATES
        return self.current_location

    def estimate_distance_from_rssi(self, device_id, raw_rssi, band=None, model='log_distance', use_shadow=True):
        """
        Use our new adaptive filter + EnhancedDistanceEstimator to get a final distance.
        model can be 'log_distance', 'free_space', 'hata', 'ensemble', 'ml', 'gaussian_process', etc.
        """
        # 1) Run the adaptive filter to get a stable RSSI
        smoothed_rssi = self.adaptive_filter.update_rssi(device_id, raw_rssi)

        # 2) Optionally store some history for debugging
        if device_id not in self.device_rssi_history:
            self.device_rssi_history[device_id] = []
        self.device_rssi_history[device_id].append(smoothed_rssi)
        if len(self.device_rssi_history[device_id]) > self.max_history_len:
            self.device_rssi_history[device_id].pop(0)

        # 3) Estimate distance from the smoothed RSSI
        distance = self.distance_estimator.estimate_distance(
            smoothed_rssi,
            model=model,
            apply_shadowing=use_shadow,
            device_id=device_id,
            band=band
        )
        return distance

    def scan_network_devices(self):
        """
        Scan the network for connected devices with improved distance estimation.
        Also detect devices that have disconnected since the last scan.
        """
        connected_devices = []
        try:
            hostname = socket.gethostname()
            local_ip = socket.gethostbyname(hostname)
            ip_parts = local_ip.split('.')
            network_prefix = '.'.join(ip_parts[:-1])
            arp_request = scapy.ARP(pdst=f"{network_prefix}.0/24")
            broadcast = scapy.Ether(dst="ff:ff:ff:ff:ff:ff")
            arp_request_broadcast = broadcast / arp_request
            answered_list = scapy.srp(arp_request_broadcast, timeout=1, verbose=False)[0]
            current_time = time.time()
            lat, lng = self.get_current_location()

            current_scan_macs = set()

            for element in answered_list:
                ip = element[1].psrc
                mac = element[1].hwsrc
                if ip == local_ip:
                    continue
                signal_strength = None
                band = None  # if we can parse 5GHz vs. 2.4GHz, put it here.

                # Attempt WMI-based info (Windows)
                try:
                    if self.w:
                        for interface in self.w.Win32_NetworkAdapter():
                            if interface.NetConnectionStatus == 2:
                                network_config = self.w.query(
                                    f"SELECT * FROM Win32_NetworkAdapterConfiguration WHERE Index = {interface.Index}"
                                )
                                if network_config:
                                    for config in network_config:
                                        if (hasattr(config, 'IPAddress') and
                                            config.IPAddress and
                                            ip in config.IPAddress):
                                            # Attempt to read signal from WMI if possible
                                            wireless_interface = self.w.query(
                                                "SELECT * FROM MSNdis_80211_ReceivedSignalStrength"
                                            )
                                            if wireless_interface:
                                                for wi in wireless_interface:
                                                    if hasattr(wi, 'Ndis80211ReceivedSignalStrength'):
                                                        signal_strength = wi.Ndis80211ReceivedSignalStrength
                                                        # We can't reliably get band here, but if you can, do so
                                                        break
                except Exception as wmi_err:
                    logging.warning(f"WMI error for device {ip}: {wmi_err}")
                
                # Fallback to ping-based approximation if we didn’t get anything from WMI
                if not signal_strength:
                    try:
                        ping_cmd = ['ping', '-n', '1'] if platform.system().lower() == 'windows' else ['ping', '-c', '1']
                        ping_cmd.append(ip)
                        ping_result = subprocess.run(
                            ping_cmd,
                            stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE,
                            timeout=1,
                            text=True
                        )
                        latency_match = re.search(r'time=(\d+)ms', ping_result.stdout)
                        if latency_match:
                            latency = int(latency_match.group(1))
                            latency = max(5, min(1000, latency))
                            # Convert latency to a rough RSSI guess
                            signal_strength = -40 - 10 * math.log10(latency / 10.0)
                            signal_strength = max(-90, min(-30, signal_strength))
                    except (subprocess.SubprocessError, subprocess.TimeoutExpired):
                        signal_strength = -85  # if we have no info at all

                # Let’s do the advanced distance estimation (e.g. ML or ensemble).
                # For illustration, let's pick 'ml' below. You can pick any model you like.
                # Use 'log_distance' if you haven't loaded an ML model.
                distance_model = 'ml'  # or 'log_distance', 'gaussian_process', etc.
                distance = None
                if signal_strength is not None:
                    distance = self.estimate_distance_from_rssi(
                        device_id=mac,
                        raw_rssi=signal_strength,
                        band=band, 
                        model=distance_model,
                        use_shadow=True
                    )
                
                # Calculate approximate location if we have a distance
                if distance is not None and distance > 0:
                    # Reuse or generate a random bearing for each device
                    if mac in self.devices and 'bearing' in self.devices[mac]:
                        bearing = self.devices[mac]['bearing']
                    else:
                        bearing = np.random.uniform(0, 360)
                        if mac in self.devices:
                            self.devices[mac]['bearing'] = bearing
                        else:
                            self.devices[mac] = {'bearing': bearing}

                    lat_offset = distance * math.cos(math.radians(bearing)) / 111320
                    lng_offset = distance * math.sin(math.radians(bearing)) / (
                        111320 * math.cos(math.radians(lat))
                    )
                    device_location = (lat + lat_offset, lng + lng_offset)
                else:
                    device_location = (lat, lng)
                
                # For logging/storing
                try:
                    calc_distance = geopy.distance.distance((lat, lng), device_location).meters
                except Exception as e:
                    logging.warning(f"Error calculating geopy distance: {e}")
                    calc_distance = 0
                
                device_info = {
                    'ip': ip,
                    'mac': mac,
                    'time': current_time,
                    'signal_strength': signal_strength,
                    'location': device_location,
                    'distance': calc_distance,
                    'host_location': (lat, lng),
                    'connection_status': 'connected'
                }
                self.devices[mac] = device_info
                connected_devices.append(device_info)

                self.device_distances.append({
                    'time': current_time,
                    'device_id': mac,
                    'distance': calc_distance,
                    'signal_strength': signal_strength,
                    'lat': device_location[0],
                    'lng': device_location[1],
                    'connection_status': 'connected'
                })
                current_scan_macs.add(mac)

            # Disconnected devices
            disconnected_macs = self.previous_scan_macs - current_scan_macs
            for dmac in disconnected_macs:
                disc_time = time.time()
                self.device_distances.append({
                    'time': disc_time,
                    'device_id': dmac,
                    'distance': None,
                    'signal_strength': None,
                    'lat': None,
                    'lng': None,
                    'connection_status': 'disconnected'
                })
                if dmac in self.devices:
                    self.devices[dmac]['connection_status'] = 'disconnected'

            self.previous_scan_macs = current_scan_macs
            return connected_devices
        
        except Exception as e:
            logging.error(f"Error scanning network: {e}")
            return []

