# main.py

from imports import *
from wi_fi_mapper import WiFiMapper
import threading
from datetime import datetime
import platform
import argparse
import logging
import pandas as pd

from config import (
    DATA_COLLECTION_DURATION,
    DATA_COLLECTION_INTERVAL,
    DASH_PORT,
    AP_SCAN_INTERVAL
)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def main():
    parser = argparse.ArgumentParser(description='Real-time WiFi Signal Strength Mapper with Asynchronous Processing')
    parser.add_argument('--duration', type=float, default=DATA_COLLECTION_DURATION,
                        help='Data collection duration in minutes')
    parser.add_argument('--interval', type=float, default=DATA_COLLECTION_INTERVAL,
                        help='Interval between measurements in seconds')
    parser.add_argument('--port', type=int, default=DASH_PORT,
                        help='Port for the Dash web server')
    parser.add_argument('--device-scan-interval', type=float, default=10.0,
                        help='Interval between device scans in seconds')
    parser.add_argument('--ap-scan-interval', type=float, default=AP_SCAN_INTERVAL,
                        help='Interval between full WiFi AP scans in seconds')
    
    args = parser.parse_args()
    mapper = WiFiMapper()
    
    # Start raw data collection thread
    collection_thread = threading.Thread(
        target=mapper.collect_data_continuously,
        args=('position_1', args.duration, args.interval)
    )
    collection_thread.daemon = True
    collection_thread.start()

    # Start background processing thread (for filtering, adaptive smoothing, etc.)
    processing_thread = threading.Thread(
        target=mapper.process_data_continuously
    )
    processing_thread.daemon = True
    processing_thread.start()

    # Optionally, start the AP scanning thread (if needed)
    ap_scan_thread = threading.Thread(
        target=mapper.scan_visible_networks_continuously,
        args=(args.ap_scan_interval,)
    )
    ap_scan_thread.daemon = True
    ap_scan_thread.start()

    # Create and run the Dash app (with incremental updates)
    app = mapper.create_dash_app(args.duration, args.interval)
    logger.info(f"Starting WiFi Mapper Dashboard on port {args.port}")
    app.run_server(debug=False, host='0.0.0.0', port=args.port)

    # When the server stops, gracefully shut down threads and save logs
    mapper.collection_active = False
    collection_thread.join()
    processing_thread.join()
    ap_scan_thread.join()

    if not mapper.data.empty:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"wifi_mapping_{timestamp}.csv"
        mapper.data.to_csv(filename, index=False)
        logger.info(f"Saved full data log to {filename}")

    if mapper.device_tracker.device_distances:
        device_df = pd.DataFrame(mapper.device_tracker.device_distances)
        if not device_df.empty:
            device_filename = f"device_tracking_{timestamp}.csv"
            device_df.to_csv(device_filename, index=False)
            logger.info(f"Saved device tracking data to {device_filename}")

    logger.info("WiFi Mapping completed")

if __name__ == "__main__":
    try:
        if platform.system().lower() != 'windows':
            logger.warning("This application is optimized for Windows. Some features may be limited on other OS.")
        main()
    except KeyboardInterrupt:
        logger.info("Application terminated by user")
    except Exception as e:
        logger.error(f"Application error: {e}", exc_info=True)

