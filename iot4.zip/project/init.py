# init.py

import os
import re
import math
import time
import socket
import json
import logging
import argparse
from datetime import datetime
from pathlib import Path
import threading
import queue
from collections import defaultdict

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
from filterpy.kalman import KalmanFilter
from scipy.stats import norm
import scapy.all as scapy
import requests
import pythoncom
import geopy.distance

# Type hints for consistency
from typing import List, Dict, Optional, Tuple

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Re-export commonly used classes from submodules for centralized imports
from .distance_estimator import EnhancedDistanceEstimator
from .device_tracker import DeviceTracker
from .wi_fi_mapper import WiFiMapper
